package com.app.fruits;

public class Mango extends Fruit{

	public Mango(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
}
