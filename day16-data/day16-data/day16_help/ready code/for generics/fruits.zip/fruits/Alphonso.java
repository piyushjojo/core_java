package com.app.fruits;

public class Alphonso extends Mango{

	public Alphonso(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
}
